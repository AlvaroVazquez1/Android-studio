package com.example.listado

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.example.listado.R

// Clase Alumno
data class Alumno(
    val nombre: String,
    val cuenta: String,
    val correo: String,
    val image: Int
)

// Adaptador para el RecyclerView
class AlumnoAdapter(private val alumnos: List<Alumno>) : RecyclerView.Adapter<AlumnoAdapter.AlumnoViewHolder>() {

    class AlumnoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)

        val tvNombre: TextView = itemView.findViewById(R.id.tvNombre)
        val tvCuenta: TextView = itemView.findViewById(R.id.tvCuenta)
        val tvCorreo: TextView = itemView.findViewById(R.id.tvCorreo)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlumnoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alumno, parent, false)
        return AlumnoViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlumnoViewHolder, position: Int) {
        val alumno = alumnos[position]
        holder.tvNombre.text = alumno.nombre
        holder.tvCuenta.text = alumno.cuenta
        holder.tvCorreo.text = alumno.correo
        holder.imageView.setImageResource(alumno.image)
    }

    override fun getItemCount(): Int {
        return alumnos.size
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AlumnoAdapter
    private var alumnos = mutableListOf<Alumno>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configurar RecyclerView
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Lista de ejemplo de alumnos
        alumnos = mutableListOf(
            Alumno("Juan Pérez", "123456", "juan@ucol.com", R.drawable.ic_launcher_foreground),
            Alumno("María López", "654321", "maria@ucol.com", R.drawable.ic_launcher_foreground)
        )

        adapter = AlumnoAdapter(alumnos)
        recyclerView.adapter = adapter

        // Configurar el botón flotante para agregar alumnos
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener {
            mostrarDialogoAgregarAlumno()
        }
    }

    // Función para mostrar un diálogo que permita agregar un nuevo alumno
    private fun mostrarDialogoAgregarAlumno() {
        // Crear el layout para el diálogo
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_alumno, null)

        val nombreInput = dialogView.findViewById<EditText>(R.id.editNombre)
        val cuentaInput = dialogView.findViewById<EditText>(R.id.editCuenta)
        val correoInput = dialogView.findViewById<EditText>(R.id.editCorreo)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Agregar Alumno")
            .setView(dialogView)
            .setPositiveButton("Agregar") { _, _ ->
                val nombre = nombreInput.text.toString()
                val cuenta = cuentaInput.text.toString()
                val correo = correoInput.text.toString()

                if (nombre.isNotEmpty() && cuenta.isNotEmpty() && correo.isNotEmpty()) {
                    // Agregar el nuevo alumno a la lista
                    val nuevoAlumno = Alumno(nombre, cuenta, correo, R.drawable.ic_launcher_foreground)
                    alumnos.add(nuevoAlumno)
                    adapter.notifyItemInserted(alumnos.size - 1)
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }
}
